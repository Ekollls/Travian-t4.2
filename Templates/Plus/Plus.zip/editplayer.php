<?php
##################################################################
## Page:        winner.php                                      ##
## Description: When the player builds Wonder of the World      ##
##              to level 100 the winner details are shown.      ##
##              tells the players the game is over              ##
## Authors:     aggenkeech - and a little help from Eyas95      ##
## Created:     31/03/2012                                      ##
##################################################################
include("GameEngine/Protection.php");
include("GameEngine/Village.php");
$sssssss = false;
include "Templates/html.tpl";
$query = mysql_query('SELECT * FROM '.TB_PREFIX.'users WHERE `id` = '.mysql_real_escape_string((isset($_GET['id']) ? (int)$_GET['id'] : '0')));
if(mysql_num_rows($query) != 1){header("location: dorf1.php");exit();}
$row = mysql_fetch_assoc($query);
if(isset($_POST['search'])){
$gold = preg_replace('/[^0-9]/','',$_POST['addgold']);
	$access = $_POST['access'];
	if($access != $row['access']){
		mysql_query('UPDATE '.TB_PREFIX.'users SET access = '.$access.' WHERE `id` = '.$_GET['id']);
	}
	if($gold > 0){
		mysql_query('UPDATE '.TB_PREFIX.'users SET gold = gold + '.$gold.', giftgold = giftgold + '.$gold.' WHERE `id` = '.$_GET['id']);
	}
	$sssssss = true;
}
?>
<body class="v35 webkit chrome plus">
<?php include_once("analyticstracking.php") ?>
	<div id="wrapper"> 
		<img id="staticElements" src="img/x.gif" alt="" /> 
		<div id="logoutContainer"> 
			<a id="logout" href="logout.php" title="<?php echo LOGOUT; ?>">&nbsp;</a> 
		</div> 
		<div class="bodyWrapper"> 
			<img style="filter:chroma();" src="img/x.gif" id="msfilter" alt="" /> 
			<div id="header"> 
				<div id="mtop">
					<a id="logo" href="<?php echo HOMEPAGE; ?>" target="_blank" title="<?php echo SERVER_NAME ?>"></a>
					<ul id="navigation">
						<li id="n1" class="resources">
							<a class="" href="dorf1.php" accesskey="1" title="<?php echo HEADER_DORF1; ?>"></a>
						</li>
						<li id="n2" class="village">
							<a class="" href="dorf2.php" accesskey="2" title="<?php echo HEADER_DORF2; ?>"></a>
						</li>
						<li id="n3" class="map">
							<a class="" href="karte.php" accesskey="3" title="<?php echo HEADER_MAP; ?>"></a>
						</li>
						<li id="n4" class="stats">
							<a class="" href="statistiken.php" accesskey="4" title="<?php echo HEADER_STATS; ?>"></a>
						</li>
<?php
    	if(count($database->getMessage($session->uid,7)) >= 1000) {
			$unmsg = "+1000";
		} else { $unmsg = count($database->getMessage($session->uid,7)); }
		
    	if(count($database->getMessage($session->uid,8)) >= 1000) {
			$unnotice = "+1000";
		} else { $unnotice = count($database->getMessage($session->uid,8)); }
?>
<li id="n5" class="reports"> 
<a href="berichte.php" accesskey="5" title="<?php echo HEADER_NOTICES; ?><?php if($message->nunread){ echo' ('.count($database->getMessage($session->uid,8)).')'; } ?>"></a>
<?php
if($message->nunread){
	echo "<div class=\"ltr bubble\" title=\"".$unnotice." ".HEADER_NOTICES_NEW."\" style=\"display:block\">
			<div class=\"bubble-background-l\"></div>
			<div class=\"bubble-background-r\"></div>
			<div class=\"bubble-content\">".$unnotice."</div></div>";
}
?>
</li>
<li id="n6" class="messages"> 
<a href="nachrichten.php" accesskey="6" title="<?php echo HEADER_MESSAGES; ?><?php if($message->unread){ echo' ('.count($database->getMessage($session->uid,7)).')'; } ?>"></a> 
<?php
if($message->unread) {
	echo "<div class=\"ltr bubble\" title=\"".$unmsg." ".HEADER_MESSAGES_NEW."\" style=\"display:block\">
			<div class=\"bubble-background-l\"></div>
			<div class=\"bubble-background-r\"></div>
			<div class=\"bubble-content\">".$unmsg."</div></div>";
}
?>
</li>

</ul>
<div class="clear"></div> 
</div> 
</div>
					<div id="mid"> 
 <a id="ingameManual" href="help.php"><img class="question" alt="Help" src="img/x.gif"></a>
												<div class="clear"></div> 
						<div id="contentOuterContainer"> 
							<div class="contentTitle">&nbsp;</div> 
							<div class="contentContainer"> 
						<div id="content" class="plus">
                        <script type="text/javascript">
					window.addEvent('domready', function()
					{
						$$('.subNavi').each(function(element)
						{
							new Travian.Game.Menu(element);
						});
					});
				</script>
<h1>ویرایش بازیکن</h1>
<form action="" method='post'>
<table>
<tr>
	<th>نام</th>
	<th>ایمیل</th>
	<th>دسترسی</th>
	<th>افزودن طلا</th>
</tr>
<?php 
echo "<tr>
	<td>{$row['username']}</td>
	<td>{$row['email']}</td>
	<td>";
	echo "<select name=\"access\" dir='ltr'>";
	echo "<option value=\"0\"".($row['access'] == 0 ? 'selected="selected"':'').">banned</option>";
	echo "<option value=\"2\"".($row['access'] == 2 ? 'selected="selected"':'').">player</option>";
	echo "<option value=\"8\"".($row['access'] == 8 ? 'selected="selected"':'').">multihunter</option>";
	echo "<option value=\"9\"".($row['access'] == 9 ? 'selected="selected"':'').">admin</option>";
	echo "</select></td>
	<td><input type='text' name='addgold' class='text name' size='5' value='0'/></td>
</tr>";?>
</table><br>
<button type="submit" value="search" name="search" id="btn_ok" class="dynamic_img " src="img/x.gif">
            <div class="button-container"><div class="button-position"><div class="btl"><div class="btr"><div class="btc"></div></div></div><div class="bml"><div class="bmr"><div class="bmc"></div></div></div><div class="bbl"><div class="bbr"><div class="bbc"></div></div></div></div><div class="button-contents">ثبت</div></div></button>
</form>
<?php 
if($sssssss)echo 'تنظیمات جدید با موفقیت ذخیره شد!<Br>';?>
</div>
<div class="clear"></div>
</div>
<div class="contentFooter">&nbsp;</div>
					</div>
                    
<?php
include("Templates/sideinfo.tpl");
include("Templates/footer.tpl");
include("Templates/header.tpl");
include("Templates/res.tpl");
include("Templates/vname.tpl");
include("Templates/quest.tpl");
?>
	</div>
<div id="ce"></div>
</div>
</body>
</html>

