<?php
$merchant_code		= '5255685';
$terminal_code		= '786077854';
$redirect_address	= '';
$referrer_address	= '';
$delivery_days		= 1;
$key_file			= 'Templates/Plus/privateKey.pem';
//End of file: pasargad_config.php